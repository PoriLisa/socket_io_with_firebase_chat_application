package com.example.socket.constant

object Constants {
    const val CHAT_SERVER_URL = "http://192.168.1.71:3000" //Chat server ip and port


}