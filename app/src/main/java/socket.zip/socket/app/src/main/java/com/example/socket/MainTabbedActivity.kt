package com.example.socket

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainTabbedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_tabbed)
    }
}